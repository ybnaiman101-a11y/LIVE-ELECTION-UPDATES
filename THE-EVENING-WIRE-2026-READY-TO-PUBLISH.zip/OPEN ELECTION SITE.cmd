@echo off
setlocal
chcp 65001 >nul 2>nul
title ELECTIONWIRE 2026 - OPEN MY LIVE SITE
cd /d "%~dp0"
echo.
echo  ==========================================================
echo     ELECTIONWIRE 2026  -  LIVE ELECTION NEWS
echo  ==========================================================
echo.
echo  Your news site will open automatically in your browser.
echo  Keep this window open to receive live headlines.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0OPEN ELECTION SITE.ps1"
if errorlevel 1 (
  echo.
  echo  Site could not start. See the error above.
  echo  Check your internet connection, then try this file again.
  echo.
  pause
)
endlocal
