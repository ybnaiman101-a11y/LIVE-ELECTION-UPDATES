import http from 'node:http';
import fs from 'node:fs';
import { promises as fsp } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC = path.join(ROOT, 'public');
const CACHE = process.env.CACHE_PATH || path.join(ROOT, 'data', 'cache.json');
const PORT = Number(process.env.PORT || 3000);
const POLL_MS = Math.max(30_000, Number(process.env.POLL_INTERVAL_MS || 60_000));
const CONCURRENCY = Math.max(1, Math.min(10, Number(process.env.FETCH_CONCURRENCY || 5)));
const RETAIN_MS = 4 * 24 * 60 * 60 * 1000;
const KEEP_MAX = 750;
const MAX_XML_BYTES = 3_000_000;

// Twelve requested outlets, plus fifteen additional editorial/news sources.
// 'google' is used for sources that have no reliably maintained public RSS feed.
const SOURCES = [
  { id:'fox', name:'Fox News', domain:'foxnews.com', feed:'https://moxie.foxnews.com/google-publisher/politics.xml', group:'Requested' },
  { id:'cnn', name:'CNN', domain:'cnn.com', group:'Requested' },
  { id:'nyt', name:'The New York Times', domain:'nytimes.com', feed:'https://rss.nytimes.com/services/xml/rss/nyt/Politics.xml', group:'Requested' },
  { id:'nbc', name:'NBC News', domain:'nbcnews.com', feed:'https://feeds.nbcnews.com/nbcnews/public/politics', group:'Requested' },
  { id:'abc', name:'ABC News', domain:'abcnews.go.com', feed:'https://abcnews.go.com/abcnews/politicsheadlines', group:'Requested' },
  { id:'newsmax', name:'Newsmax', domain:'newsmax.com', feed:'https://www.newsmax.com/rss/Politics/1/', group:'Requested' },
  { id:'msnow', name:'MS NOW', domain:'ms.now', feed:'https://www.ms.now/category/elections/feed', group:'Requested' },
  { id:'dailywire', name:'The Daily Wire', domain:'dailywire.com', group:'Requested' },
  { id:'reuters', name:'Reuters', domain:'reuters.com', group:'Requested' },
  { id:'ap', name:'Associated Press', domain:'apnews.com', group:'Requested' },
  { id:'wapo', name:'The Washington Post', domain:'washingtonpost.com', feed:'https://feeds.washingtonpost.com/rss/politics', group:'Requested' },
  { id:'examiner', name:'Washington Examiner', domain:'washingtonexaminer.com', feed:'https://www.washingtonexaminer.com/feed/', group:'Requested' },
  { id:'politico', name:'POLITICO', domain:'politico.com', feed:'https://rss.politico.com/politics-news.xml', group:'Additional' },
  { id:'hill', name:'The Hill', domain:'thehill.com', feed:'https://thehill.com/feed/', group:'Additional' },
  { id:'cbs', name:'CBS News', domain:'cbsnews.com', feed:'https://www.cbsnews.com/latest/rss/main', group:'Additional' },
  { id:'npr', name:'NPR', domain:'npr.org', feed:'https://feeds.npr.org/1014/rss.xml', group:'Additional' },
  { id:'pbs', name:'PBS NewsHour', domain:'pbs.org', feed:'https://www.pbs.org/newshour/feeds/rss/headlines', group:'Additional' },
  { id:'usatoday', name:'USA TODAY', domain:'usatoday.com', group:'Additional' },
  { id:'wsj', name:'The Wall Street Journal', domain:'wsj.com', group:'Additional' },
  { id:'bloomberg', name:'Bloomberg', domain:'bloomberg.com', group:'Additional' },
  { id:'axios', name:'Axios', domain:'axios.com', feed:'https://api.axios.com/feed/', group:'Additional' },
  { id:'guardian', name:'The Guardian', domain:'theguardian.com', feed:'https://www.theguardian.com/us-news/us-politics/rss', group:'Additional' },
  { id:'breitbart', name:'Breitbart', domain:'breitbart.com', feed:'https://www.breitbart.com/feed/', group:'Additional' },
  { id:'nypost', name:'New York Post', domain:'nypost.com', feed:'https://nypost.com/feed/', group:'Additional' },
  { id:'natreview', name:'National Review', domain:'nationalreview.com', feed:'https://www.nationalreview.com/feed/', group:'Additional' },
  { id:'bbc', name:'BBC News', domain:'bbc.com', feed:'https://feeds.bbci.co.uk/news/world/us_and_canada/rss.xml', group:'Additional' },
  { id:'newsnation', name:'NewsNation', domain:'newsnationnow.com', group:'Additional' }
];

const relevantRe = /\b(elections?|midterms?|vot(?:e|es|ed|ing|ers?)|turnout|ballots?|polling places?|exit polls?|senate|senators?|governor(?:s|ship)?|gubernatorial|congressional|redistricting|campaigns?|candidates?|house seats?|house races?|house control|house majority|election night|election day|races? to watch|primary election|special election|vote count|swing states?|precincts?|recounts?|polls? close|electoral)\b/i;
const resultRe = /\b(project(?:ed|ion)?|called the race|wins? (?:the |a )?(?:race|election|seat)|victor(?:y|ies)|defeat(?:s|ed)?|results?|count(?:ing|ed)? votes?|recount|concedes?|concession|flips? (?:the |a )?seat)\b/i;
const votingRe = /\b(early voting|votes?|voters?|ballots?|turnout|polls? (?:open|close|closed)|election day|precincts?|mail.in|absentee)\b/i;
const senateRe = /\b(senate|senator|senatorial)\b/i;
const houseRe = /\b(house of representatives|house (?:seat|race|majority|control)|congress(?:ional)?|district \d+|\bNY-\d+\b)\b/i;
const governorRe = /\b(governors?|gubernatorial|governorship)\b/i;
const STATES = {
  'AL':'Alabama','AK':'Alaska','AZ':'Arizona','AR':'Arkansas','CA':'California','CO':'Colorado','CT':'Connecticut','DE':'Delaware','FL':'Florida','GA':'Georgia','HI':'Hawaii','ID':'Idaho','IL':'Illinois','IN':'Indiana','IA':'Iowa','KS':'Kansas','KY':'Kentucky','LA':'Louisiana','ME':'Maine','MD':'Maryland','MA':'Massachusetts','MI':'Michigan','MN':'Minnesota','MS':'Mississippi','MO':'Missouri','MT':'Montana','NE':'Nebraska','NV':'Nevada','NH':'New Hampshire','NJ':'New Jersey','NM':'New Mexico','NY':'New York','NC':'North Carolina','ND':'North Dakota','OH':'Ohio','OK':'Oklahoma','OR':'Oregon','PA':'Pennsylvania','RI':'Rhode Island','SC':'South Carolina','SD':'South Dakota','TN':'Tennessee','TX':'Texas','UT':'Utah','VT':'Vermont','VA':'Virginia','WA':'Washington','WV':'West Virginia','WI':'Wisconsin','WY':'Wyoming','DC':'Washington, D.C.'
};

const store = {
  stories: [],
  ids: new Set(),
  sourceState: Object.fromEntries(SOURCES.map(s => [s.id, { status: 'waiting', lastAttempt: null, lastOk: null, items:0, via:null, error:null }])),
  lastCycle: null, lastSuccessfulCycle: null, cycling:false, initialized:false, cycleNo:0
};
const clients = new Set();
let saveDebounce;

function safeURL(raw) {
  try { const u = new URL(raw); return u.protocol === 'https:' || u.protocol === 'http:' ? u.toString() : null; } catch { return null; }
}
function decodeEntities(text='') {
  const named = {amp:'&',lt:'<',gt:'>',quot:'"',apos:"'",nbsp:' ',mdash:'—',ndash:'–',hellip:'…',lsquo:'‘',rsquo:'’',ldquo:'“',rdquo:'”',bull:'•',copy:'©',reg:'®',trade:'™',eacute:'é'};
  return String(text).replace(/&(#x[\da-f]+|#\d+|[a-z][\da-z]+);/gi, (raw, code) => {
    if (code[0] === '#') { const n = code[1]?.toLowerCase() === 'x' ? parseInt(code.slice(2),16) : parseInt(code.slice(1),10); return Number.isInteger(n) && n > 0 && n <= 0x10FFFF ? String.fromCodePoint(n) : raw; }
    return named[code.toLowerCase()] ?? raw;
  });
}
function cleanText(raw='') {
  const expanded = String(raw).replace(/^\s*<!\[CDATA\[([\s\S]*?)\]\]>\s*$/, '$1');
  return decodeEntities(expanded.replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim());
}
function extractTag(block, name) {
  const expr = new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${name}>`, 'i');
  return (block.match(expr) || [])[1] || '';
}
function parseRSS(xml) {
  const entries = [...xml.matchAll(/<(item|entry)(?:\s[^>]*)?>([\s\S]*?)<\/\1>/gi)];
  if (!entries.length && !/<(?:rss|feed|rdf:RDF)\b/i.test(xml)) throw new Error('The response was not a recognized RSS/Atom feed');
  return entries.map(([ ,type, body]) => {
    const atom = type.toLowerCase() === 'entry';
    const linkEl = body.match(/<link\b([^>]*?)\/?\s*>/i);
    const href = linkEl?.[1]?.match(/\bhref\s*=\s*["']([^"']+)["']/i)?.[1];
    const link = atom ? (href || cleanText(extractTag(body,'link'))) : cleanText(extractTag(body,'link'));
    return {
      title: cleanText(extractTag(body, 'title')),
      description: cleanText(extractTag(body, 'description') || extractTag(body,'summary') || extractTag(body,'content:encoded')),
      link,
      published: cleanText(extractTag(body, 'pubDate') || extractTag(body, 'published') || extractTag(body, 'updated') || extractTag(body, 'dc:date'))
    };
  }).filter(entry => entry.title && safeURL(entry.link));
}
function googleFeed(domain) {
  const q = `site:${domain} (election OR midterms OR voting OR senate OR governor OR "House race") when:3d`;
  return `https://news.google.com/rss/search?q=${encodeURIComponent(q)}&hl=en-US&gl=US&ceid=US%3Aen`;
}
async function getFeed(url) {
  const res = await fetch(url, {
    signal: AbortSignal.timeout(12_000),
    headers: { 'User-Agent':'ElectionLiveDashboard/1.0 (+public RSS reader; headline aggregation)', 'Accept':'application/rss+xml, application/atom+xml, application/xml, text/xml, */*' },
    redirect:'follow'
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const size = Number(res.headers.get('content-length'));
  if (size > MAX_XML_BYTES) throw new Error('RSS response exceeded size limit');
  const body = await res.text();
  if (body.length > MAX_XML_BYTES) throw new Error('RSS response exceeded size limit');
  return parseRSS(body);
}
function classify(title, desc) {
  const str = `${title} ${desc}`;
  const topics=[];
  if (resultRe.test(title)) topics.push('results');
  if (votingRe.test(str)) topics.push('voting');
  if (senateRe.test(str)) topics.push('senate');
  if (houseRe.test(str)) topics.push('house');
  if (governorRe.test(str)) topics.push('governors');
  if (!topics.length) topics.push('national');
  const stateCodes = Object.entries(STATES).filter(([code,name]) => {
    const text = `${title} ${desc.slice(0,200)}`;
    return new RegExp(`\\b${name.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}\\b`, 'i').test(text)
      || new RegExp(`\\b${code}[-–]\\d{1,2}\\b`).test(text);
  }).map(([code])=>code);
  return {topics, states:stateCodes};
}
function normalStory(entry, source, via) {
  const title = via === 'Google News index' ? entry.title.replace(new RegExp(`\\s+-\\s+${source.name.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}$`,'i'), '') : entry.title;
  if (!relevantRe.test(title + ' ' + entry.description.slice(0,450))) return null;
  const ts = Date.parse(entry.published);
  if (!Number.isFinite(ts)) return null; // No fabricated publication times.
  if (ts < Date.now() - RETAIN_MS || ts > Date.now() + 2 * 60 * 60 * 1000) return null;
  const url=safeURL(entry.link);
  if (!url) return null;
  const id = crypto.createHash('sha256').update(source.id+'|'+title.toLowerCase().replace(/\W+/g,' ').trim()+'|'+new Date(ts).toISOString()).digest('hex').slice(0,20);
  return {
    id, title: title.slice(0,230), excerpt: entry.description.slice(0,230),
    url, publishedAt: new Date(ts).toISOString(), observedAt: new Date().toISOString(),
    sourceId: source.id, source: source.name, domain: source.domain, via,
    ...classify(title,entry.description)
  };
}
async function pollSource(source) {
  const state=store.sourceState[source.id];
  state.lastAttempt=new Date().toISOString();
  let entries, via;
  try {
    if (source.feed) {
      try { entries=await getFeed(source.feed); via='Publisher RSS'; }
      catch (e) { entries=await getFeed(googleFeed(source.domain)); via='Google News fallback'; }
    } else { entries=await getFeed(googleFeed(source.domain)); via='Google News index'; }
    const prepared=entries.map(e=>normalStory(e,source,via)).filter(Boolean);
    state.status='ok'; state.lastOk=new Date().toISOString(); state.via=via; state.items=prepared.length; state.error=null;
    return prepared;
  } catch(e) {
    state.status='error'; state.error=String(e.message).slice(0,130); state.items=0;
    return [];
  }
}
function publish(event, payload) {
  const packet=`event: ${event}\ndata: ${JSON.stringify(payload)}\n\n`;
  for(const res of clients) { try { res.write(packet); } catch { clients.delete(res); } }
}
function snapshot() {
  return {
    stories: store.stories,
    sources: SOURCES.map(s=>({id:s.id,name:s.name,domain:s.domain,group:s.group, ...store.sourceState[s.id]})),
    meta: {initialized:store.initialized, lastCycle:store.lastCycle, lastSuccessfulCycle:store.lastSuccessfulCycle, pollingIntervalSeconds:POLL_MS/1000, totalSources:SOURCES.length, serverTime:new Date().toISOString(), cycleNo:store.cycleNo}
  };
}
function queueSave(){
  clearTimeout(saveDebounce);
  saveDebounce=setTimeout(async()=>{
    try { await fsp.mkdir(path.dirname(CACHE),{recursive:true}); await fsp.writeFile(CACHE,JSON.stringify({stories:store.stories},null,2),'utf8'); }
    catch(e){console.warn('Cache save failed:',e.message);}
  },1800);
  saveDebounce.unref?.();
}
async function loadCache(){
  try {
    const json=JSON.parse(await fsp.readFile(CACHE,'utf8'));
    if (Array.isArray(json.stories)) {
      store.stories=json.stories.filter(s=>s?.id && s?.publishedAt && Date.parse(s.publishedAt)>Date.now()-RETAIN_MS).slice(0,KEEP_MAX);
      store.ids=new Set(store.stories.map(s=>s.id));
    }
  } catch { /* first launch */ }
}
async function pollAll() {
  if(store.cycling) return;
  store.cycling=true;
  const initial=!store.initialized;
  try {
    const batches=[];
    let cursor=0;
    await Promise.all(Array.from({length:Math.min(CONCURRENCY,SOURCES.length)},async()=>{
      while(cursor<SOURCES.length) {
        const s=SOURCES[cursor++];
        const result=await pollSource(s);
        batches.push(...result);
        // Publish source health quickly even if other sources are still in flight.
        if(!initial) publish('sources', {sources:snapshot().sources, meta:snapshot().meta});
      }
    }));
    const newStories=[];
    for(const item of batches) {
      if(store.ids.has(item.id)) continue;
      store.ids.add(item.id); newStories.push(item);
    }
    store.stories.push(...newStories);
    store.stories=store.stories.filter(s=>Date.parse(s.publishedAt)>Date.now()-RETAIN_MS)
      .sort((a,b)=>Date.parse(b.publishedAt)-Date.parse(a.publishedAt)).slice(0,KEEP_MAX);
    store.ids=new Set(store.stories.map(s=>s.id));
    store.lastCycle=new Date().toISOString(); store.cycleNo++;
    if(SOURCES.some(s=>store.sourceState[s.id].status==='ok')) store.lastSuccessfulCycle=store.lastCycle;
    store.initialized=true;
    if(!initial) {
      for(const item of newStories.sort((a,b)=>Date.parse(a.publishedAt)-Date.parse(b.publishedAt)).slice(-35)) publish('story',item);
    }
    publish('snapshot',snapshot());
    queueSave();
    console.log(`${new Date().toISOString()} | scan ${store.cycleNo} | +${newStories.length} headlines | ${SOURCES.filter(s=>store.sourceState[s.id].status==='ok').length}/${SOURCES.length} feeds healthy${initial?' | initial load (alerts suppressed)':''}`);
  } finally {store.cycling=false;}
}

const mime = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.webp':'image/webp','.ico':'image/x-icon'};
const server=http.createServer(async(req,res)=>{
  const pathname = new URL(req.url,'http://localhost').pathname;
  if(pathname==='/api/stream') {
    res.writeHead(200,{'Content-Type':'text/event-stream; charset=utf-8','Cache-Control':'no-cache, no-transform','Connection':'keep-alive','X-Accel-Buffering':'no','Access-Control-Allow-Origin':'*'});
    res.write('retry: 4000\n\n'); clients.add(res);
    res.write(`event: snapshot\ndata: ${JSON.stringify(snapshot())}\n\n`);
    req.on('close',()=>clients.delete(res));
    return;
  }
  if(pathname==='/api/stories'||pathname==='/api/status'||pathname==='/api/sources') {
    const body=pathname==='/api/stories'?snapshot():pathname==='/api/status'?snapshot().meta:{sources:snapshot().sources};
    res.writeHead(200,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});
    res.end(JSON.stringify(body)); return;
  }
  if(pathname==='/health') {
    res.writeHead(store.lastSuccessfulCycle?200:503,{'Content-Type':'application/json'});
    res.end(JSON.stringify({ok:Boolean(store.lastSuccessfulCycle),lastSuccessfulCycle:store.lastSuccessfulCycle})); return;
  }
  const filename=pathname==='/'?'/index.html':pathname;
  const resolved=path.resolve(PUBLIC,'.'+filename);
  if(!resolved.startsWith(PUBLIC+path.sep) && resolved!==path.join(PUBLIC,'index.html')) {res.writeHead(403);res.end('Forbidden');return;}
  try {
    const stat=await fsp.stat(resolved);
    if(!stat.isFile()) throw new Error('Not a file');
    res.writeHead(200,{'Content-Type':mime[path.extname(resolved)]||'application/octet-stream','Cache-Control':'public, max-age=300'});
    fs.createReadStream(resolved).pipe(res);
  } catch {res.writeHead(404);res.end('Not found');}
});

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  server.listen(PORT,'0.0.0.0', async()=>{
    console.log(`\nELECTION NIGHT LIVE · http://localhost:${PORT} · ${SOURCES.length} news sources · scan every ${POLL_MS/1000}s`);
    await loadCache();
    void pollAll();
    setInterval(()=>void pollAll(),POLL_MS).unref();
    setInterval(()=>publish('heartbeat',{time:new Date().toISOString()}),20_000).unref();
  });
}

export {parseRSS, normalStory, googleFeed, classify, SOURCES, relevantRe};
