import test from 'node:test';
import assert from 'node:assert/strict';
import { parseRSS, normalStory, classify, SOURCES, googleFeed } from '../server.mjs';
test('parses RSS XML and safely removes markup',()=>{
 const rss='<?xml version="1.0"?><rss><channel><item><title><![CDATA[Texas election &amp; Senate update]]></title><link>https://example.com/abc</link><description><![CDATA[<p>Ballots counted</p>]]></description><pubDate>Sun, 01 Nov 2026 04:15:00 GMT</pubDate></item></channel></rss>';
 const [r]=parseRSS(rss);assert.equal(r.title,'Texas election & Senate update');assert.equal(r.link,'https://example.com/abc');assert.equal(r.description,'Ballots counted');
});
test('parses Atom href and published',()=>{
 const feed='<feed xmlns="http://www.w3.org/2005/Atom"><entry><title>Senate race updates</title><link rel="alternate" href="https://example.com/senate"/><summary>New ballots</summary><published>2026-11-01T04:00:00Z</published></entry></feed>';
 assert.equal(parseRSS(feed)[0].link,'https://example.com/senate');
});
test('rejects unexpected HTML',()=>assert.throws(()=>parseRSS('<html><body>Access denied</body></html>')));
test('classifies topics and states',()=>{
 const x=classify('Texas Senate election results','Voters across Iowa');
 assert(x.topics.includes('results'));assert(x.topics.includes('senate'));assert(x.states.includes('TX'));assert(x.states.includes('IA'));
});
test('uses 27 unique, properly grouped outlets',()=>{
 assert.equal(SOURCES.length,27);assert.equal(SOURCES.filter(s=>s.group==='Requested').length,12);assert.equal(SOURCES.filter(s=>s.group==='Additional').length,15);
 assert.match(googleFeed('cnn.com'),/site%3Acnn.com/);
});
