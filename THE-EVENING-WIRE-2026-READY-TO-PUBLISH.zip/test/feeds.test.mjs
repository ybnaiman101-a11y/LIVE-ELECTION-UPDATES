import test from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {setTimeout as delay} from 'node:timers/promises';
const port=33771;
let child;
test.before(async()=>{
  child=spawn(process.execPath,['server.mjs'],{cwd:process.cwd(),env:{...process.env,PORT:String(port),CACHE_PATH:'/tmp/election-live-test-no-feed-cache.json',POLL_INTERVAL_MS:'600000'},stdio:'ignore'});
  for(let i=0;i<45;i++){try{const r=await fetch(`http://localhost:${port}/api/status`);if(r.ok)return;}catch{}await delay(100);}
  throw Error('server not ready');
});
test.after(()=>child?.kill());
test('Homepage responds with markup',async()=>{const r=await fetch(`http://localhost:${port}/`);assert.equal(r.status,200);assert.match(await r.text(),/ELECTION NIGHT/);});
test('API returns configured 27 sources',async()=>{const r=await fetch(`http://localhost:${port}/api/stories`);const data=await r.json();assert.equal(data.sources.length,27);assert.equal(new Set(data.sources.map(s=>s.id)).size,27);assert.equal(data.sources.filter(s=>s.group==='Requested').length,12);});
test('unknown path responds 404',async()=>{const r=await fetch(`http://localhost:${port}/not-here`);assert.equal(r.status,404);});
test('SSE endpoint announces a snapshot',async()=>{const controller=new AbortController();const r=await fetch(`http://localhost:${port}/api/stream`,{signal:controller.signal});assert.match(r.headers.get('content-type'),/text\/event-stream/);const {value}=await r.body.getReader().read();assert.match(new TextDecoder().decode(value),/event: snapshot/);controller.abort();});

test('Evening Wire logo is served as an image', async()=>{const home=await (await fetch(`http://localhost:${port}/`)).text(); assert.match(home,/evening-wire-logo\.webp/); const r=await fetch(`http://localhost:${port}/evening-wire-logo.webp`);assert.equal(r.status,200);assert.match(r.headers.get('content-type'),/image\/webp/);assert.ok((await r.arrayBuffer()).byteLength>2000);});
