#!/bin/sh
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Please install Node.js 20 or newer from https://nodejs.org/"
  exit 1
fi
printf 'Open http://localhost:3000 in your browser\n'
node server.mjs
