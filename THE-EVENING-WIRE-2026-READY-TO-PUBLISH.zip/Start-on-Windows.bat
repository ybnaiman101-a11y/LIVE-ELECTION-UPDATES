@echo off
call "%~dp0OPEN ELECTION SITE.cmd"
