(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const safeRead = (key, fallback) => { try { const v=localStorage.getItem(key); return v===null?fallback:JSON.parse(v); } catch{return fallback;} };
  const safeStore = (key, value) => {try{localStorage.setItem(key,JSON.stringify(value));}catch{}};
  const state = {
    stories:[], sources:[], meta:{initialized:false}, topic:'all', query:'', stateFilter:'all',
    selectedSources:new Set(safeRead('election-selected-sources',[])),
    sourceFilterOn:safeRead('election-source-filter-on',false),
    alerts:safeRead('election-alerts',true), desktop:false, sound:safeRead('election-sound',false),
    sinceOpen:0, seenNew:new Set(), limit:25, connected:false, firstSnapshot:false, lastEventAt:null
  };
  let es=null, audioCtx=null, stateTimer=null;
  const STATES={'AK':'Alaska','AL':'Alabama','AR':'Arkansas','AZ':'Arizona','CA':'California','CO':'Colorado','CT':'Connecticut','DC':'District of Columbia','DE':'Delaware','FL':'Florida','GA':'Georgia','HI':'Hawaii','IA':'Iowa','ID':'Idaho','IL':'Illinois','IN':'Indiana','KS':'Kansas','KY':'Kentucky','LA':'Louisiana','MA':'Massachusetts','MD':'Maryland','ME':'Maine','MI':'Michigan','MN':'Minnesota','MO':'Missouri','MS':'Mississippi','MT':'Montana','NC':'North Carolina','ND':'North Dakota','NE':'Nebraska','NH':'New Hampshire','NJ':'New Jersey','NM':'New Mexico','NV':'Nevada','NY':'New York','OH':'Ohio','OK':'Oklahoma','OR':'Oregon','PA':'Pennsylvania','RI':'Rhode Island','SC':'South Carolina','SD':'South Dakota','TN':'Tennessee','TX':'Texas','UT':'Utah','VA':'Virginia','VT':'Vermont','WA':'Washington','WI':'Wisconsin','WV':'West Virginia','WY':'Wyoming'};
  const topics={results:'RESULTS',voting:'VOTING',senate:'SENATE',house:'HOUSE',governors:'GOVERNOR',national:'ELECTION'};
  const iconURL = domain => `https://www.google.com/s2/favicons?domain=${encodeURIComponent(domain)}&sz=32`;
  const el = (tag,cls,text) => {const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;};
  const fmtET = date => new Intl.DateTimeFormat('en-US',{timeZone:'America/New_York',hour:'numeric',minute:'2-digit',hour12:true}).format(date);
  function relativeTime(value) {
    const ts=Date.parse(value); if(!Number.isFinite(ts))return 'Time unavailable';
    const diff=Math.max(0,Date.now()-ts); if(diff<60_000)return 'Just published';
    if(diff<60*60_000)return `${Math.floor(diff/60_000)} min ago`;
    if(diff<24*60*60_000)return `${Math.floor(diff/3600000)}h ago`;
    return new Intl.DateTimeFormat('en-US',{timeZone:'America/New_York',month:'short',day:'numeric',hour:'numeric',minute:'2-digit'}).format(new Date(ts))+' ET';
  }
  function validURL(raw){try{const u=new URL(raw);return ['http:','https:'].includes(u.protocol)?u.href:'#';}catch{return '#';}}
  function visibleStories(){
    const q=state.query.toLowerCase().trim();
    return state.stories.filter(s=>{
      if(state.topic!=='all' && !s.topics?.includes(state.topic))return false;
      if(state.stateFilter!=='all' && !s.states?.includes(state.stateFilter) && !`${s.title} ${s.excerpt}`.toLowerCase().includes(STATES[state.stateFilter].toLowerCase()))return false;
      if(state.sourceFilterOn && !state.selectedSources.has(s.sourceId))return false;
      if(q && !(`${s.title} ${s.excerpt} ${s.source}`.toLowerCase().includes(q)))return false;
      return true;
    });
  }
  function pickTopic(story){for(const id of ['results','voting','senate','house','governors'])if(story.topics?.includes(id))return id;return 'national';}
  function storyCard(story){
    const card=el('article','story-card'+(state.seenNew.has(story.id)?' is-new':''));
    const body=el('div','story-body'); const top=el('div','story-top');
    const pub=el('span','publisher-badge');
    const icon=el('img','publisher-favicon');icon.src=iconURL(story.domain||'example.org');icon.alt='';icon.loading='lazy';pub.append(icon,el('span','',story.source));top.append(pub);
    const topic=pickTopic(story);top.append(el('span','story-topic '+topic,topics[topic]));
    if(state.seenNew.has(story.id))top.append(el('span','new-item-pill','JUST IN'));
    const time=el('span','story-time',relativeTime(story.publishedAt));time.title=`Published: ${story.publishedAt}`;top.append(time);
    body.append(top);
    const head=el('h3');const link=el('a','',story.title);link.href=validURL(story.url);link.target='_blank';link.rel='noopener noreferrer';head.append(link);body.append(head);
    if(story.excerpt)body.append(el('p','',story.excerpt));
    const foot=el('div','story-footer');const link2=el('a','open-story','READ ORIGINAL ARTICLE ↗');link2.href=link.href;link2.target='_blank';link2.rel='noopener noreferrer';foot.append(link2);
    foot.append(el('span','story-meta',story.via||'RSS'));
    if(story.states?.length)foot.append(el('span','story-meta','STATE: '+story.states.slice(0,4).join(' · ')));
    body.append(foot);card.append(body);return card;
  }
  function renderStories(){
    const list=$('storyList');list.replaceChildren(); const items=visibleStories();
    if(!state.firstSnapshot){const blank=el('div','blank-state');blank.append(el('span','blank-spinner'),el('h3','', 'Connecting to the newsrooms'),el('p','', 'Checking election coverage. Verified published headlines appear here after the first successful scan.'));list.append(blank);}
    else if(!items.length){const blank=el('div','blank-state');blank.append(el('span','no-result-symbol','◈'),el('h3','', state.stories.length?'No headlines match your filters':'No election headlines received yet'),el('p','',state.stories.length?'Try another topic, search, state, or news source.':'The server has not retrieved relevant headlines yet. Check Source Monitor for errors, or wait for the next scan.'));list.append(blank);}
    else {const frag=document.createDocumentFragment();for(const item of items.slice(0,state.limit))frag.append(storyCard(item));list.append(frag);}
    $('storySummary').textContent=`${Math.min(items.length,state.limit).toLocaleString()} of ${items.length.toLocaleString()} matching headlines · ${state.stories.length.toLocaleString()} in the archive`;
    $('loadMoreBtn').hidden=items.length<=state.limit;
    $('activeFilterNote').hidden=!(state.sourceFilterOn&&state.selectedSources.size===0);
    if(state.sourceFilterOn&&state.selectedSources.size===0)$('activeFilterNote').textContent='You have selected zero sources. Use Sources to choose the outlets you want to follow.';
    $('selectedSourceCount').textContent=state.sourceFilterOn?`(${state.selectedSources.size})`:'';
  }
  function sourceStatus(source){return source.status==='ok'?'ok':source.status==='error'?'error':'waiting';}
  function sourceEntry(source){
    const row=el('div','source-entry');row.title=source.error?`${source.name}: ${source.error}`:`${source.name}: ${source.via||'not checked yet'}${source.lastOk?' · last success '+new Date(source.lastOk).toLocaleString():''}`;
    const icon=el('img');icon.src=iconURL(source.domain);icon.alt='';icon.loading='lazy';row.append(icon,el('span','source-name',source.name),el('span','source-led '+sourceStatus(source)));return row;
  }
  function renderSources(){
    const a=$('requestedSources'), b=$('additionalSources');a.replaceChildren();b.replaceChildren();
    for(const source of state.sources){(source.group==='Requested'?a:b).append(sourceEntry(source));}
    const ok=state.sources.filter(s=>s.status==='ok').length, error=state.sources.filter(s=>s.status==='error').length, waiting=state.sources.filter(s=>s.status==='waiting').length;
    $('activeCount').textContent=state.firstSnapshot?ok:'—';
    $('sourceCount').textContent=state.sources.length||27;
    $('sourceProgress').style.width=`${ok/(state.sources.length||27)*100}%`;
    const badge=$('monitorBadge');badge.className='small-status'+(ok===0&&waiting===0?' offline':error?' degraded':ok?' healthy':'');
    badge.textContent=ok===0&&waiting===0?'OFFLINE':error?'DEGRADED':ok?'LIVE':'CHECKING';
    $('monitorText').textContent=state.sources.length?`${ok} responding · ${error} errors · ${waiting} waiting. Select or hover a source for more details.`:'Waiting for the first server response.';
  }
  function renderSummary(){
    const lastHour=Date.now()-3600000;
    $('hourCount').textContent=state.stories.filter(s=>Date.parse(s.publishedAt)>=lastHour).length;
    $('newCount').textContent=state.sinceOpen;
    const when=state.meta.lastCycle;
    $('lastRefresh').textContent=when?`Last scan ${fmtET(new Date(when))} ET`:'Checking feeds…';
    const healthy=state.sources.filter(s=>s.status==='ok').length;
    const live=state.connected&&healthy>0;
    const conn=$('connectionState');conn.className='connection'+(live?' is-live':state.connected?'':' is-error');
    conn.innerHTML='<span class="green-dot"></span> '+(live?'LIVE FEEDS':state.connected?'FEED CHECK':'RECONNECTING');
    $('footerStatus').textContent=`News feed: ${live?'connected':state.connected?'checking':'disconnected'} · scans approximately every ${state.meta.pollingIntervalSeconds||60}s`;
    const ticker=state.stories.slice(0,5).map(s=>`${s.source.toUpperCase()}: ${s.title}`);
    $('tickerText').replaceChildren();
    if(ticker.length){ticker.forEach((t,i)=>{if(i)$('tickerText').append(el('span','ticker-dot','✦'));$('tickerText').append(document.createTextNode(t));});}
    else $('tickerText').textContent='Tracking 27 sources. Live headlines will appear after the feeds respond.';
  }
  function renderAll(){renderSources();renderSummary();renderStories();}
  function snapshot(obj){
    if(!obj||!Array.isArray(obj.stories)||!Array.isArray(obj.sources))return;
    // The first snapshot is a baseline; preexisting headlines do not trigger alerts.
    state.stories=obj.stories;
    state.sources=obj.sources;
    state.meta=obj.meta||{};
    state.firstSnapshot=true;
    renderAll();
  }
  function makeToast(story){
    const stack=$('toastStack');const toast=el('div','toast');
    const top=el('div','toast-top');top.append(el('span','', '✦ NEW ELECTION UPDATE'));
    const close=el('button','toast-close','×');close.type='button';close.setAttribute('aria-label','Dismiss alert');close.addEventListener('click',()=>toast.remove());top.append(close);toast.append(top);
    toast.append(el('h4','',story.title));const foot=el('div','toast-footer');foot.append(el('span','',story.source+' · '+fmtET(new Date(story.publishedAt))+' ET'));
    const link=el('a','', 'OPEN STORY ↗');link.href=validURL(story.url);link.target='_blank';link.rel='noopener noreferrer';foot.append(link);toast.append(foot);
    stack.prepend(toast);while(stack.children.length>4)stack.lastElementChild.remove();setTimeout(()=>toast.remove(),14000);
  }
  function playSound(){
    try {audioCtx ||= new (window.AudioContext||window.webkitAudioContext)();if(audioCtx.state==='suspended')audioCtx.resume();
      const now=audioCtx.currentTime;for(const [i,f] of [680,920].entries()){const o=audioCtx.createOscillator();const gain=audioCtx.createGain();o.type='sine';o.frequency.value=f;gain.gain.setValueAtTime(.0001,now+i*.12);gain.gain.exponentialRampToValueAtTime(.055,now+i*.12+.018);gain.gain.exponentialRampToValueAtTime(.0001,now+i*.12+.13);o.connect(gain);gain.connect(audioCtx.destination);o.start(now+i*.12);o.stop(now+i*.12+.14);}}
    catch{} // Audio APIs may be disabled or blocked by browser autoplay policy.
  }
  function maybeDesktopNotification(story){
    if(!state.desktop || !('Notification' in window) || Notification.permission!=='granted')return;
    try {const n=new Notification('Election update · '+story.source,{body:story.title,tag:'election-'+story.id,icon:'/favicon.svg',silent:true});n.onclick=()=>{window.open(validURL(story.url),'_blank','noopener');n.close();};}catch{}
  }
  function incoming(story){
    if(!story?.id||state.seenNew.has(story.id))return;
    if(state.stories.some(s=>s.id===story.id))return;
    state.seenNew.add(story.id);state.sinceOpen++;
    state.stories=[story,...state.stories].sort((a,b)=>Date.parse(b.publishedAt)-Date.parse(a.publishedAt)).slice(0,750);
    renderSummary();renderStories();
    const relevant=(!state.sourceFilterOn||state.selectedSources.has(story.sourceId))&&(state.stateFilter==='all'||story.states?.includes(state.stateFilter))&&(state.topic==='all'||story.topics?.includes(state.topic));
    if(state.alerts && relevant){makeToast(story);if(state.sound)playSound();maybeDesktopNotification(story);}
  }
  function connect(){
    if(!('EventSource' in window))return fallbackPolling();
    es=new EventSource('/api/stream');
    es.onopen=()=>{state.connected=true;renderSummary();};
    es.onerror=()=>{state.connected=false;renderSummary();};
    es.addEventListener('snapshot',e=>{try{snapshot(JSON.parse(e.data));}catch(error){console.error('Snapshot parse error',error);}});
    es.addEventListener('sources',e=>{try{const data=JSON.parse(e.data);state.sources=data.sources;state.meta=data.meta;renderSources();renderSummary();}catch{}});
    es.addEventListener('story',e=>{try{incoming(JSON.parse(e.data));}catch{}});
    es.addEventListener('heartbeat',()=>{state.lastEventAt=Date.now();});
  }
  function fallbackPolling(){
    const run=async()=>{try{const resp=await fetch('/api/stories',{cache:'no-store'});const next=await resp.json();if(state.firstSnapshot){const old=new Set(state.stories.map(s=>s.id));for(const s of [...next.stories].reverse())if(!old.has(s.id))incoming(s);}snapshot(next);state.connected=true;}catch{state.connected=false;}renderSummary();};run();setInterval(run,30_000);
  }
  function initClock(){
    const update=()=>{$('clock').textContent=new Intl.DateTimeFormat('en-US',{timeZone:'America/New_York',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:true}).format(new Date())+' ET';
      const now=Date.now();const election=new Date('2026-11-03T00:00:00-05:00').getTime(); const diff=election-now;
      if(diff>0){const days=Math.floor(diff/86400000);const h=Math.floor((diff%86400000)/3600000);$('countdown').textContent=`${days}d ${h}h until Election Day (Eastern Time)`;}else $('countdown').textContent='Election Day: November 3, 2026';
    };update();setInterval(update,1000);
  }
  function buildStateSelect(){const sel=$('stateSelect');for(const [code,name] of Object.entries(STATES).sort((a,b)=>a[1].localeCompare(b[1]))){const opt=el('option','',name);opt.value=code;sel.append(opt);}sel.addEventListener('change',()=>{state.stateFilter=sel.value;state.limit=25;renderStories();});}
  function initControls(){
    $('topicTabs').addEventListener('click',e=>{const btn=e.target.closest('[data-topic]');if(!btn)return;state.topic=btn.dataset.topic;state.limit=25;for(const b of $('topicTabs').querySelectorAll('button'))b.classList.toggle('active',b===btn);renderStories();});
    $('searchInput').addEventListener('input',e=>{state.query=e.target.value;state.limit=25;renderStories();});
    $('loadMoreBtn').addEventListener('click',()=>{state.limit+=25;renderStories();});
    $('alertsBtn').addEventListener('click',()=>{state.alerts=!state.alerts;safeStore('election-alerts',state.alerts);updateAlertBtn();});
    $('settingsBtn').addEventListener('click',()=>{const open=$('settingsBar').hidden;$('settingsBar').hidden=!open;$('settingsBtn').setAttribute('aria-expanded',String(open));});
    $('soundNotify').checked=state.sound;
    $('soundNotify').addEventListener('change',e=>{state.sound=e.target.checked;safeStore('election-sound',state.sound);if(state.sound)playSound();});
    $('desktopNotify').addEventListener('change',async e=>{
      if(!e.target.checked){state.desktop=false;$('notifyHelp').textContent='Desktop notifications disabled.';return;}
      if(!('Notification' in window)){$('notifyHelp').textContent='This browser does not support desktop notifications.';e.target.checked=false;return;}
      if(!window.isSecureContext){$('notifyHelp').textContent='Desktop notifications require HTTPS or localhost.';e.target.checked=false;return;}
      const permission=await Notification.requestPermission();state.desktop=permission==='granted';e.target.checked=state.desktop;$('notifyHelp').textContent=state.desktop?'Browser notifications enabled while this page is open.':'Notification permission was not granted.';
    });
    $('expandSourcesBtn').addEventListener('click',()=>{const open=$('additionalPanel').hidden;$('additionalPanel').hidden=!open;$('expandSourcesBtn').setAttribute('aria-expanded',String(open));$('expandSourcesBtn').innerHTML=open?'HIDE ADDITIONAL SOURCES <span>⌃</span>':'SHOW 15 ADDITIONAL SOURCES <span>⌄</span>';});
    const backdrop=$('sourceBackdrop');const close=()=>backdrop.hidden=true;
    $('sourceMenuBtn').addEventListener('click',()=>{renderSourcePicker();backdrop.hidden=false;});
    $('closeSourceModal').addEventListener('click',close);
    backdrop.addEventListener('click',e=>{if(e.target===backdrop)close();});
    document.addEventListener('keydown',e=>{if(e.key==='Escape')close();});
    $('selectAllSources').addEventListener('click',()=>{for(const x of $('sourcePicker').querySelectorAll('input'))x.checked=true;});
    $('clearAllSources').addEventListener('click',()=>{for(const x of $('sourcePicker').querySelectorAll('input'))x.checked=false;});
    $('applySources').addEventListener('click',()=>{const checks=[...$('sourcePicker').querySelectorAll('input')];const chosen=checks.filter(x=>x.checked).map(x=>x.value);state.sourceFilterOn=chosen.length!==checks.length;state.selectedSources=new Set(chosen);safeStore('election-source-filter-on',state.sourceFilterOn);safeStore('election-selected-sources',chosen);state.limit=25;close();renderStories();});
    updateAlertBtn();
  }
  function renderSourcePicker(){
    const picker=$('sourcePicker');picker.replaceChildren();
    for(const src of state.sources){const row=el('label','source-option');const input=el('input');input.type='checkbox';input.value=src.id;input.checked=!state.sourceFilterOn||state.selectedSources.has(src.id);const icon=el('img');icon.src=iconURL(src.domain);icon.alt='';row.append(input,icon,el('span','',src.name));picker.append(row);}
  }
  function updateAlertBtn(){$('alertsState').textContent=state.alerts?'ON':'OFF';$('alertsBtn').style.background=state.alerts?'':'#2c3949';}
  buildStateSelect();initControls();initClock();
  // A quick initial HTTP fetch avoids waiting for the first EventSource event in quirky browsers.
  fetch('/api/stories',{cache:'no-store'}).then(r=>r.ok?r.json():Promise.reject(Error(`HTTP ${r.status}`))).then(snapshot).catch(()=>{}).finally(connect);
  setInterval(()=>{if(state.firstSnapshot){renderSummary(); if(document.visibilityState==='visible')renderStories();}},60_000);
})();
