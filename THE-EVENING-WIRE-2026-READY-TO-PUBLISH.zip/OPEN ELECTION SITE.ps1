# One-click Windows launcher for ElectionWire 2026.
# Uses an installed Node 20+ if available; otherwise downloads a portable,
# SHA-256-verified official Node.js executable into this folder.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $root

function Get-UsableNode {
    $localNode = Join-Path $root '.runtime\node.exe'
    foreach ($candidate in @($localNode, 'node.exe')) {
        try {
            $version = & $candidate --version 2>$null
            if ($LASTEXITCODE -eq 0 -and $version -match '^v(\d+)\.') {
                if ([int]$Matches[1] -ge 20) { return $candidate }
            }
        } catch { }
    }
    return $null
}

function Install-PortableNode {
    $dir = Join-Path $root '.runtime'
    New-Item -ItemType Directory -Path $dir -Force | Out-Null
    $version = 'v22.14.0'
    # SHA256 fingerprints published in the official Node.js v22.14.0 release manifest.
    $architecture = $env:PROCESSOR_ARCHITECTURE
    switch ($architecture) {
        'ARM64' { $arch = 'win-arm64'; $expected = 'b37c6950508f266d066deb91abe2050fcd3f19e34c86ca89eed72efb40090b57' }
        'x86'   { $arch = 'win-x86'; $expected = 'd52f9f1b03eca305dbaa23e251fe612efbb48a99aaeab6ffa073ee1c111b28e0' }
        default { $arch = 'win-x64'; $expected = '33b1bc1a8aca11fd5a4f2699e51019c63c0af30cf437701d07af69be7706771b' }
    }
    $url = "https://nodejs.org/dist/$version/$arch/node.exe"
    $out = Join-Path $dir 'node.exe'
    $tmp = Join-Path $dir 'node.download'
    Write-Host 'First-time setup: fetching official Node.js runtime...' -ForegroundColor Yellow
    Write-Host "Source: $url"
    Write-Host 'No installer or administrator privileges required.'
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $ProgressPreference = 'SilentlyContinue'
        Invoke-WebRequest -Uri $url -OutFile $tmp -UseBasicParsing -TimeoutSec 240
        $actual = (Get-FileHash -LiteralPath $tmp -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actual -ne $expected) {
            throw "Node.js SHA256 verification failed. The downloaded file will not run."
        }
        Move-Item -LiteralPath $tmp -Destination $out -Force
        Write-Host 'Secure setup finished.' -ForegroundColor Green
        return $out
    } finally {
        Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
    }
}

function Test-FreePort([int]$port) {
    $listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, $port)
    try { $listener.Start(); return $true }
    catch { return $false }
    finally { $listener.Stop() }
}

try {
    # Reopening the launcher while the site is running just opens its existing tab.
    try {
        $existing = Invoke-RestMethod 'http://127.0.0.1:3000/api/stories' -TimeoutSec 2
        if ($existing.sources.Count -eq 27) {
            Write-Host 'Site is already running. Opening it now...' -ForegroundColor Green
            Start-Process 'http://localhost:3000'
            exit 0
        }
    } catch { }

    $node = Get-UsableNode
    if (-not $node) { $node = Install-PortableNode }
    $port = 3000
    while ($port -lt 3020 -and -not (Test-FreePort $port)) { $port++ }
    if ($port -ge 3020) { throw 'No free local port was found (3000-3019).' }
    $env:PORT = [string]$port
    $url = "http://localhost:$port"
    Write-Host ''
    Write-Host 'Starting 27-source election newsroom...' -ForegroundColor Cyan
    $process = Start-Process -FilePath $node -ArgumentList 'server.mjs' -WorkingDirectory $root -NoNewWindow -PassThru
    $ready = $false
    for ($i = 0; $i -lt 45; $i++) {
        if ($process.HasExited) { throw "The web server closed unexpectedly (exit code $($process.ExitCode))." }
        try {
            $reply = Invoke-WebRequest -UseBasicParsing -Uri "$url/api/stories" -TimeoutSec 2
            if ($reply.StatusCode -eq 200) { $ready = $true; break }
        } catch { }
        Start-Sleep -Milliseconds 350
    }
    if (-not $ready) { throw "The local server did not respond at $url." }
    Write-Host "Opening site: $url" -ForegroundColor Green
    Start-Process $url
    Write-Host ''
    Write-Host 'LIVE SITE OPEN. Keep this window open for automatic news updates.' -ForegroundColor Green
    Write-Host 'Close this window when you are finished. You can double-click again later.'
    Write-Host 'Sources can take time to return articles. Feed errors appear on the site.'
    Wait-Process -Id $process.Id
} catch {
    Write-Host ''
    Write-Host "Could not open the live site: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host 'You can still open the OFFLINE PREVIEW.html file without setup.' -ForegroundColor Yellow
    exit 1
}
