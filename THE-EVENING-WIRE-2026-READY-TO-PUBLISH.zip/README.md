# Publish THE EVENING WIRE 2026 online

For one-click cloud setup, read **PUBLISH ONLINE - START HERE.txt**.

# THE EVENING WIRE — 2026 Election Night Live

An actual self-hosted election news dashboard. Aggregates article headlines from **27 outlets** (the 12 requested outlets plus 15 additional sources), highlights newly discovered updates, and pushes them to every open browser through **Server-Sent Events (SSE)**.

**It is not an official election-results feed.** It reports the headlines that publishers post; it does not count votes or declare races. No API keys and no npm install are needed.

## Start it on your computer

1. Extract the downloaded ZIP into a normal folder.
2. On **Windows**, double-click **`OPEN ELECTION SITE.cmd`**. That is all: the launcher starts the local server and opens your browser automatically.
3. If Node.js 20+ is not installed, the launcher downloads a **portable official Node.js executable** and checks its SHA-256 fingerprint. No admin rights or manual installation are required. You need internet access on first launch.
4. Keep the terminal open while the website is in use. To open again later, double-click the same file.
5. On Mac/Linux, run `./Start-on-Mac-Linux.sh` (Node.js 20+ required).

The site uses **THE EVENING WIRE — TODAY’S TOP STORIES** logo (shown in the header and included as `public/evening-wire-logo.png`). The included **`OFFLINE PREVIEW.html`** opens directly with a double-click and shows the visual design, but it **does not retrieve live headlines**. See `START HERE - READ ME.txt` for quick instructions.

The system immediately checks RSS feeds, then scans again **every 60 seconds** (configurable via `POLL_INTERVAL_MS`). Newly discovered headlines appear as **on-screen alerts**. Optionally enable desktop notifications and alert sounds using **Alert Settings**. Desktop notifications require HTTPS or localhost and work while the site remains open.

**Please note:** the site needs outbound HTTPS access to publisher/news feeds. If the host blocks external network requests, Source Monitor will display errors rather than fabricated articles. You can change feeds in `server.mjs` as publishers update them.

## Put it online

Deploy the included `Dockerfile` to a **continuously running service** such as Railway, Fly.io, or an always-on Docker host:

- Repository/service root is this folder.
- Command: `node server.mjs` (or build with included Dockerfile).
- Expose the `PORT` assigned by the hosting provider; the server reads `process.env.PORT`.
- Enable HTTPS at the hosting platform for desktop notifications.
- Add persistent storage for `data/cache.json` if you want story history to survive host restarts.
- Do **not** deploy as static HTML, because the backend must fetch RSS feeds and hold SSE connections. A serverless-only deployment that sleeps or enforces short timeouts will interrupt updates.

Local scans run regardless of whether browsers are open, while the server is operating. If you want alerts on a closed browser or phone, add a Web Push service with user subscriptions (not included). Current notifications are displayed to users with an open page.

## Sources

**Requested (12):** Fox News, CNN, The New York Times, NBC News, ABC News, Newsmax, MS NOW, The Daily Wire, Reuters, Associated Press, The Washington Post, Washington Examiner.

**Additional (15):** POLITICO, The Hill, CBS News, NPR, PBS NewsHour, USA TODAY, The Wall Street Journal, Bloomberg, Axios, The Guardian, Breitbart, New York Post, National Review, BBC News, NewsNation.

Publisher RSS feeds are preferred where available. For CNN, Reuters, Associated Press and other publishers without a reliable public RSS feed, the server uses **Google News RSS search** restricted to that source and election keywords. It also automatically falls back to Google News if a publisher RSS feed fails. The article cards explicitly display whether the link arrived through publisher RSS or Google News. Google News may delay indexing, and publisher feeds may be delayed, incomplete, or periodically unavailable; “live” means a connected running feed, **not guaranteed instant publication detection**. Source Monitor displays failures and response status.

## Behavior

- **On-screen popups:** enabled by default for headlines detected after you open the page. No old stories trigger popups at startup.
- **Desktop notification:** optional, browser permission required. Works only while page is open; not background push.
- **Sound:** off by default, can be enabled with a click.
- **Filtering:** Results, Voting, Senate, House, Governor, all 50 states, publisher selection, text search.
- **Deduplication:** the same publisher headline with the same original publication timestamp is combined into one entry; different outlets remain separate.
- **Attribution:** only headlines and very brief feed excerpts are shown; links lead to the source. The aggregator is not endorsed by any publisher.
- **Accuracy:** headlines and publication times come from the feeds. Feeds without a parseable publication timestamp are skipped. The dashboard does not invent vote counts, race calls, or stories.
- **Storage:** headlines are cached for four days, at most 750, in `data/cache.json`. The file is created on first run.
- **Status:** `/health` returns 200 only after at least one source successfully responds. `/api/stories` and `/api/status` expose JSON for monitoring. `/api/stream` streams live updates using SSE.

## Configuration

```sh
PORT=3000 POLL_INTERVAL_MS=60000 FETCH_CONCURRENCY=5 node server.mjs
```

The minimum poll interval is 30 seconds. Very aggressive intervals increase publisher load and the risk of rate-limiting. Real-world story freshness also depends on publisher publication and Google News indexing, not just scan frequency.

## Known limitations

- RSS availability and publication rights vary. Respect source terms of use, and verify redistribution permissions if making this a commercial public product.
- Publisher headlines may be inaccurate or changed later. Follow the original story and official election authorities for race results.
- A source can respond without election-related items; that is a healthy feed, not an election update.
- Some publishers use article URLs that redirect via Google News. Attribution still points to the source named in the RSS query.
- A network-blocked server will correctly show no stories and source errors. There is deliberately **no fake live feed**.

## Tech stack

Zero third-party runtime dependencies: Node.js 20+ server, built-in `fetch`, simple RSS/Atom parser, SSE, pure HTML/CSS/JS frontend.
